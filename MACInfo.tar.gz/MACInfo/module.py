#!/usr/bin/env python3

from pineapple.modules import Module, Request
import json
import os
import shutil
import re

module = Module('MACInfo')

OUI_FILE = '/root/.MACInfo/MLA_OUI_COMPLETE'
OUI_DIRECTORY = '/root/.MACInfo'
COMPLETE_FILE = '/root/.MACInfo/setup_complete.txt'

def move_oui_file():
    source_path = '/pineapple/modules/MACInfo/MLA_OUI_COMPLETE'

    if not os.path.exists(OUI_DIRECTORY):
        os.makedirs(OUI_DIRECTORY)

    try:
        shutil.move(source_path, OUI_FILE)
        # Set permissions to rw-r--r--
        os.system("chmod 644 {}".format(OUI_FILE))
    except Exception as e:
        return False

    message = "Do not remove this file. If you do, you will need to sideload the module again to complete the setup process."
    with open(COMPLETE_FILE, 'w') as setup_file:
        setup_file.write(message)

    return True

@module.on_start()
def on_start():
    global OUIS

    if not os.path.exists(COMPLETE_FILE):
        move_oui_file()

    try:
        with open(OUI_FILE) as f:
            OUIS = json.load(f)
    except Exception as e:
        return

@module.handles_action('check_mac')
def check_mac(request: Request):
    mac = request.user_input.upper()
    nospace_mac = mac.replace(' ', '')

    if ':' in nospace_mac:
        strip_mac = nospace_mac.replace(':', '')
    elif '-' in nospace_mac:
        strip_mac = nospace_mac.replace('-', '')

    if re.search("^([a-fA-F0-9]{2}[:-]?){1,5}[a-fA-F0-9]{1,2}?$", nospace_mac):
        for i in range(len(strip_mac), 5, -1):
            new_mac = strip_mac[:i]
            company = OUIS.get(new_mac)
            if company:
                return {'company': company}

        return {'nomac': 'No matching OUI found for the given MAC address'}
    else:
        return {'nomac': 'Not a valid MAC address'}

if __name__ == '__main__':
    module.start()